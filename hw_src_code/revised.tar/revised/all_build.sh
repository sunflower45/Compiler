#!/bin/bash
bison -d basic.y
flex basic.l
gcc -o basic basic.tab.c lex.yy.c -ll

