#!/bin/bash

gcc -o basic basic.tab.c lex.yy.c -ll

